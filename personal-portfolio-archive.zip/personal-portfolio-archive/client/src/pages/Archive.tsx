import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import { ArrowLeft, ArrowUpRight, BookOpenText, Check, FileArchive, FileText, Film, Image as ImageIcon, KeyRound, Link2, Loader2, LockKeyhole, LogOut, Pencil, Play, Plus, Search, ShieldCheck, Sparkles, StickyNote, Upload, X } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../server/routers";
import { parseArchiveVideoUrl } from "../../../shared/archive-media";
import { trpc } from "@/lib/trpc";

type ArchiveItem = inferRouterOutputs<AppRouter>["archive"]["items"]["list"][number];
type ItemKind = "video" | "image" | "file" | "note";
type FilterKind = "all" | "video" | "image" | "note";

const SESSION_KEY = "portfolio-archive-session";
const MAX_FILE_BYTES = 8 * 1024 * 1024;
const FILTERS: { id: FilterKind; label: string }[] = [
  { id: "all", label: "전체" },
  { id: "video", label: "영상" },
  { id: "image", label: "사진·파일" },
  { id: "note", label: "메모" },
];

function readAsBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("파일을 읽지 못했습니다."));
    reader.onload = () => {
      const result = String(reader.result ?? "");
      const comma = result.indexOf(",");
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.readAsDataURL(file);
  });
}

function formatBytes(bytes: number | null) {
  if (bytes == null) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function itemLabel(item: ArchiveItem) {
  if (item.kind === "video") return item.platform === "instagram" ? "INSTAGRAM REEL" : "YOUTUBE VIDEO";
  if (item.kind === "image") return "IMAGE / PHOTO";
  if (item.kind === "file") return "DOCUMENT";
  return item.legacy ? "OLD JOURNAL" : "PRIVATE NOTE";
}

function itemIcon(item: ArchiveItem) {
  if (item.kind === "video") return <Film size={17} />;
  if (item.kind === "image") return <ImageIcon size={17} />;
  if (item.kind === "file") return <FileText size={17} />;
  return <StickyNote size={17} />;
}

function ArchiveCard({
  item,
  playing,
  onPlay,
  onEdit,
}: {
  item: ArchiveItem;
  playing: boolean;
  onPlay: () => void;
  onEdit: () => void;
}) {
  const video = item.kind === "video" && item.sourceUrl ? parseArchiveVideoUrl(item.sourceUrl) : null;
  const visual = item.coverUrl || (item.kind === "image" ? item.fileUrl : null) || video?.thumbnailUrl || null;
  const tags = item.tags.split(",").map((tag) => tag.trim()).filter(Boolean);

  return (
    <article className={`archive-item-card ${item.kind === "note" ? "is-note" : ""}`}>
      <div className={`archive-item-visual ${item.kind === "video" ? "is-video" : ""} ${item.kind === "note" ? "is-note-visual" : ""}`}>
        {playing && video ? (
          <div className={`archive-player ${video.platform === "instagram" ? "instagram-player" : ""}`}>
            <iframe
              src={video.embedUrl}
              title={`${item.title} — ${video.platformLabel}`}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              loading="lazy"
              referrerPolicy="strict-origin-when-cross-origin"
            />
          </div>
        ) : visual ? (
          <img src={visual} alt={`${item.title} 미리보기`} loading="lazy" />
        ) : (
          <div className={`archive-item-placeholder kind-${item.kind}`} aria-hidden="true">
            <span className="placeholder-spark">✦</span>
            {itemIcon(item)}
            <small>{item.kind === "video" ? item.platform?.toUpperCase() ?? "VIDEO" : item.kind === "note" ? "FIELD NOTE" : "PRIVATE FILE"}</small>
          </div>
        )}
        <span className="archive-kind-chip">{itemLabel(item)}</span>
        {item.kind === "video" && video && !playing && (
          <button className="archive-play-button" onClick={onPlay} aria-label={`${item.title} 재생`}>
            <Play size={19} fill="currentColor" />
          </button>
        )}
        {playing && <button className="archive-stop-player" onClick={onPlay}><X size={13} /> 플레이어 닫기</button>}
      </div>

      <div className="archive-item-copy">
        <div className="archive-item-meta"><span>{item.platform === "instagram" ? "REEL / MEMORY" : item.platform === "youtube" ? "VIDEO / MEMORY" : item.kind === "note" ? "TEXT / MEMORY" : "OBJECT / MEMORY"}</span><time>{new Date(item.createdAt).toLocaleDateString("ko-KR")}</time></div>
        <h3>{item.title}</h3>
        {item.summary && <p className="archive-item-summary">{item.summary}</p>}
        {item.kind === "note" && item.body && (
          <details className="archive-note-expand"><summary><BookOpenText size={12} /> 전체 메모 펼치기</summary><p>{item.body}</p></details>
        )}
        {item.kind === "file" && item.fileName && <p className="archive-file-caption">{item.fileName}{item.fileSize != null ? ` · ${formatBytes(item.fileSize)}` : ""}</p>}
        {tags.length > 0 && <div className="archive-tag-row">{tags.map((tag) => <span key={tag}>#{tag}</span>)}</div>}
        <div className="archive-card-actions">
          {item.kind === "video" && item.sourceUrl && <a href={item.sourceUrl} target="_blank" rel="noreferrer"><Link2 size={13} /> 원본 링크 <ArrowUpRight size={12} /></a>}
          {(item.kind === "image" || item.kind === "file") && item.fileUrl && <a href={item.fileUrl} target="_blank" rel="noreferrer"><ArrowUpRight size={13} /> 원본 열기</a>}
          {item.resourceId != null && <button onClick={onEdit}><Pencil size={12} /> 정보 수정</button>}
          {item.legacy && <span className="archive-legacy-note">이전 보관 자료</span>}
        </div>
      </div>
    </article>
  );
}

export default function Archive() {
  const utils = trpc.useUtils();
  const status = trpc.archive.status.useQuery(undefined, { retry: false, refetchOnWindowFocus: false });
  const [code, setCode] = useState("");
  const [editorOpen, setEditorOpen] = useState(false);
  const [kind, setKind] = useState<ItemKind>("video");
  const [title, setTitle] = useState("");
  const [summary, setSummary] = useState("");
  const [body, setBody] = useState("");
  const [tags, setTags] = useState("");
  const [sourceUrl, setSourceUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [cover, setCover] = useState<File | null>(null);
  const [filter, setFilter] = useState<FilterKind>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editSummary, setEditSummary] = useState("");
  const [editTags, setEditTags] = useState("");
  const [editBody, setEditBody] = useState("");
  const unlocked = Boolean(status.data?.unlocked);
  const items = trpc.archive.items.list.useQuery(undefined, { enabled: unlocked, retry: false, staleTime: 15_000 });

  const unlock = trpc.archive.unlock.useMutation({
    onSuccess: async ({ sessionToken }) => {
      setCode("");
      try { window.sessionStorage.setItem(SESSION_KEY, sessionToken); } catch { /* Fall back to the HTTP-only cookie. */ }
      const verification = await status.refetch();
      if (!verification.data?.unlocked) {
        toast.error("코드는 확인됐지만 브라우저 세션이 전달되지 않았습니다. 다시 시도해 주세요.");
        return;
      }
      toast.success("아카이브가 열렸습니다.");
    },
    onError: (error) => toast.error(error.message || "코드를 확인해 주세요."),
  });
  const logout = trpc.archive.logout.useMutation({
    onSuccess: async () => {
      try { window.sessionStorage.removeItem(SESSION_KEY); } catch { /* Ignore unavailable sessionStorage. */ }
      setPlayingId(null);
      setEditingId(null);
      const verification = await status.refetch();
      if (verification.data?.unlocked) toast.error("아직 잠금이 확인되지 않았습니다. 페이지를 새로고침해 주세요.");
      else toast.success("아카이브를 잠갔습니다.");
    },
    onError: (error) => toast.error(error.message),
  });

  const refreshItems = async () => {
    await utils.archive.items.list.invalidate();
  };
  const createVideo = trpc.archive.items.createVideo.useMutation({ onSuccess: async () => { await refreshItems(); closeEditor(); toast.success("영상 카드를 보관했습니다."); }, onError: (error) => toast.error(error.message) });
  const createNote = trpc.archive.items.createNote.useMutation({ onSuccess: async () => { await refreshItems(); closeEditor(); toast.success("메모를 보관했습니다."); }, onError: (error) => toast.error(error.message) });
  const uploadItem = trpc.archive.items.upload.useMutation({ onSuccess: async () => { await refreshItems(); closeEditor(); toast.success("자료를 보관했습니다."); }, onError: (error) => toast.error(error.message) });
  const updateItem = trpc.archive.items.update.useMutation({ onSuccess: async () => { setEditingId(null); await refreshItems(); toast.success("카드 정보를 수정했습니다."); }, onError: (error) => toast.error(error.message) });
  const isSaving = createVideo.isPending || createNote.isPending || uploadItem.isPending;

  useEffect(() => {
    if (status.data?.unlocked === false) {
      try { window.sessionStorage.removeItem(SESSION_KEY); } catch { /* Ignore unavailable sessionStorage. */ }
    }
  }, [status.data?.unlocked]);

  useEffect(() => {
    if (status.error) toast.error("아카이브 상태를 확인하지 못했습니다.");
  }, [status.error]);

  function closeEditor() {
    setEditorOpen(false);
    setKind("video");
    setTitle("");
    setSummary("");
    setBody("");
    setTags("");
    setSourceUrl("");
    setFile(null);
    setCover(null);
  }

  function handleUnlock(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!code.trim()) return;
    unlock.mutate({ code });
  }

  function handleFileChange(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.currentTarget.files?.[0] ?? null;
    event.currentTarget.value = "";
    setFile(selected);
    if (selected && !title.trim()) setTitle(selected.name.replace(/\.[^.]+$/, ""));
  }

  function handleCoverChange(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.currentTarget.files?.[0] ?? null;
    event.currentTarget.value = "";
    setCover(selected);
  }

  async function handleSave(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!title.trim()) {
      toast.error("카드 제목을 입력해 주세요.");
      return;
    }
    if (kind === "video") {
      const parsed = parseArchiveVideoUrl(sourceUrl);
      if (!parsed) {
        toast.error("공개 YouTube 영상·Shorts 또는 Instagram Reel 주소를 확인해 주세요.");
        return;
      }
      if (cover && (cover.size > MAX_FILE_BYTES || !cover.type.startsWith("image/"))) {
        toast.error("표지 이미지는 JPG·PNG·WebP·GIF, 8MB 이하로 선택해 주세요.");
        return;
      }
      const payload = { sourceUrl, title: title.trim(), summary: summary.trim(), tags: tags.trim() };
      if (cover) {
        try {
          createVideo.mutate({ ...payload, coverFileName: cover.name, coverMimeType: cover.type, coverBase64: await readAsBase64(cover) });
        } catch {
          toast.error("표지 이미지를 읽지 못했습니다.");
        }
      } else {
        createVideo.mutate(payload);
      }
      return;
    }
    if (kind === "note") {
      createNote.mutate({ title: title.trim(), summary: summary.trim(), body, tags: tags.trim() });
      return;
    }
    if (!file) {
      toast.error(kind === "image" ? "사진을 선택해 주세요." : "PDF 또는 TXT 파일을 선택해 주세요.");
      return;
    }
    if (file.size > MAX_FILE_BYTES) {
      toast.error("파일은 8MB 이하로 선택해 주세요.");
      return;
    }
    try {
      uploadItem.mutate({ kind, fileName: file.name, mimeType: file.type || undefined, base64: await readAsBase64(file), title: title.trim(), summary: summary.trim(), tags: tags.trim() });
    } catch {
      toast.error("파일을 읽지 못했습니다.");
    }
  }

  function beginEdit(item: ArchiveItem) {
    setEditingId(item.id);
    setEditTitle(item.title);
    setEditSummary(item.summary);
    setEditTags(item.tags);
    setEditBody(item.body ?? "");
  }

  const filteredItems = useMemo(() => {
    const all = items.data ?? [];
    const query = searchTerm.trim().toLocaleLowerCase("ko-KR");
    return all.filter((item) => {
      const matchesFilter = filter === "all" || (filter === "image" ? item.kind === "image" || item.kind === "file" : item.kind === filter);
      const haystack = [item.title, item.summary, item.body ?? "", item.tags, item.sourceUrl ?? ""].join(" ").toLocaleLowerCase("ko-KR");
      return matchesFilter && (!query || haystack.includes(query));
    });
  }, [items.data, filter, searchTerm]);

  if (status.isLoading) {
    return <main className="archive-shell archive-loading"><div className="archive-pulse" /><Loader2 className="archive-spinner" size={16} />기억의 방을 확인하고 있어요…</main>;
  }

  if (!unlocked) {
    return (
      <main className="archive-shell">
        <div className="archive-topbar">
          <span className="archive-brand"><span className="pixel-glyph">♥</span> MEMORY ROOM</span>
          <Link href="/" className="archive-back"><ArrowLeft size={14} /> 포트폴리오</Link>
        </div>
        <section className="archive-lock-panel">
          <div className="archive-orbit" aria-hidden="true"><span>♥</span></div>
          <p className="archive-overline">PRIVATE SPACE · SINGLE CODE</p>
          <h1>기억의 방</h1>
          <p className="archive-lock-copy">링크, 이미지와 문장을 한곳에 보관하는<br />나만의 작은 기록실입니다.</p>
          {!status.data?.configured ? (
            <div className="archive-config-note" role="status">이 프로젝트에는 아직 접근 코드가 설정되지 않았습니다. 코드 입력란에 실제 비밀값을 넣지 말고, 프로젝트의 보안 비밀 설정에서 <code>PORTFOLIO_ARCHIVE_CODE</code>를 먼저 등록하세요.</div>
          ) : (
            <form className="archive-unlock-form" onSubmit={handleUnlock}>
              <label htmlFor="archive-code">비밀 코드</label>
              <div className="archive-code-row">
                <KeyRound size={17} aria-hidden="true" />
                <input id="archive-code" type="password" value={code} onChange={(event) => setCode(event.target.value)} autoComplete="off" placeholder="코드 입력" maxLength={256} required />
                <button type="submit" disabled={unlock.isPending} aria-label="아카이브 열기">{unlock.isPending ? <Loader2 className="archive-spinner" size={16} /> : <LogOut className="unlock-icon" size={17} />}</button>
              </div>
              <span className="archive-hint"><ShieldCheck size={13} /> 코드는 서버에서만 확인하고, 화면에는 돌려주지 않습니다.</span>
            </form>
          )}
          {unlock.error && <p className="archive-inline-error" role="alert">{unlock.error.message}</p>}
          <p className="archive-privacy-note"><LockKeyhole size={12} /> 잠금 해제 세션은 12시간 후 만료됩니다.</p>
        </section>
        <footer className="archive-footer"><span>MEMORY ROOM / PRIVATE BY DESIGN</span><span>ORIGINAL PIXEL-RPG INSPIRED INTERFACE</span></footer>
      </main>
    );
  }

  return (
    <main className="archive-shell archive-unlocked">
      <div className="archive-topbar">
        <span className="archive-brand"><span className="pixel-glyph">♥</span> MEMORY ROOM</span>
        <div className="archive-top-actions"><span className="archive-session"><span /> PRIVATE SESSION</span><button className="archive-logout" onClick={() => logout.mutate()} disabled={logout.isPending}><LogOut size={14} /> 잠그기</button></div>
      </div>

      <section className="archive-dashboard archive-library-dashboard">
        <header className="archive-welcome archive-library-welcome">
          <div><p className="archive-overline">ROOM 01 · PERSONAL COLLECTION</p><h1>수집한 장면,<br /><em>다시 만나는 곳.</em></h1><p className="archive-intro">영상 링크와 이미지, 짧은 메모를 한 장씩 쌓아 두세요.</p></div>
          <div className="archive-save-chip"><span className="pixel-glyph">♥</span><span>PRIVATE MEMORY SAVE<br /><b>SESSION VERIFIED</b></span></div>
        </header>

        <section className="archive-library-panel">
          <div className="archive-library-heading">
            <div><span className="archive-panel-index">ITEMS / YOUR MEMORY INDEX</span><h2><Sparkles size={17} /> 수집한 자료</h2></div>
            <span className="archive-count">{items.data?.length ?? 0} MEMORIES</span>
          </div>

          <div className="archive-library-toolbar">
            <div className="archive-filter-row" role="tablist" aria-label="자료 종류">
              {FILTERS.map((option) => <button key={option.id} role="tab" aria-selected={filter === option.id} className={filter === option.id ? "active" : ""} onClick={() => setFilter(option.id)}>{option.label}</button>)}
            </div>
            <div className="archive-library-tools">
              <label className="archive-search"><Search size={14} /><input value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} placeholder="제목·요약·태그 검색" aria-label="아카이브 검색" /><kbd>/</kbd></label>
              <button className="archive-add-button" onClick={() => setEditorOpen(true)}><Plus size={15} /> 자료 추가</button>
            </div>
          </div>

          {items.error && <div className="archive-library-error" role="alert">자료 목록을 불러오지 못했습니다. <button onClick={() => void items.refetch()}>다시 시도</button><small>{items.error.message}</small></div>}
          {items.isLoading && <div className="archive-library-empty"><Loader2 className="archive-spinner" size={18} /><p>기억을 펼치고 있어요…</p></div>}
          {!items.isLoading && !items.error && filteredItems.length === 0 && (
            <div className="archive-library-empty">
              <div className="empty-heart">♥</div>
              <p className="empty-kicker">{items.data?.length ? "NO MATCH FOUND" : "A NEW PAGE"}</p>
              <h3>{items.data?.length ? "이 조건에 맞는 기억이 없어요." : "아직 여백이 남아 있어요."}</h3>
              <p>{items.data?.length ? "검색어를 바꾸거나 다른 분류를 골라 보세요." : "릴스 링크, 오래 기억하고 싶은 영상, 사진이나 메모를 첫 카드로 남겨 보세요."}</p>
              {!items.data?.length && <button className="archive-add-button" onClick={() => setEditorOpen(true)}><Plus size={14} /> 첫 기억 추가</button>}
            </div>
          )}
          {filteredItems.length > 0 && <div className="archive-library-grid">{filteredItems.map((item) => <ArchiveCard key={item.id} item={item} playing={playingId === item.id} onPlay={() => setPlayingId((current) => current === item.id ? null : item.id)} onEdit={() => beginEdit(item)} />)}</div>}
        </section>

        {editingId && (
          <div className="archive-editor-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setEditingId(null); }}>
            <section className="archive-editor-window" role="dialog" aria-modal="true" aria-labelledby="archive-edit-title">
              <header className="archive-editor-head"><div><span className="archive-panel-index">EDIT / MEMORY CARD</span><h2 id="archive-edit-title">카드 정보 수정</h2></div><button className="archive-icon-button" onClick={() => setEditingId(null)} aria-label="닫기"><X size={17} /></button></header>
              <div className="archive-editor-fields"><label>제목<input value={editTitle} onChange={(event) => setEditTitle(event.target.value)} maxLength={200} /></label><label>한 줄 요약<textarea value={editSummary} onChange={(event) => setEditSummary(event.target.value)} maxLength={1000} rows={3} /></label><label>태그<input value={editTags} onChange={(event) => setEditTags(event.target.value)} placeholder="음악, 영상 아이디어" maxLength={500} /></label><label>메모 본문<textarea value={editBody} onChange={(event) => setEditBody(event.target.value)} maxLength={50_000} rows={5} /></label></div>
              <footer className="archive-editor-footer"><span>자료 파일이나 링크는 변경하지 않습니다.</span><button className="archive-add-button" disabled={!editTitle.trim() || updateItem.isPending} onClick={() => { const item = items.data?.find((entry) => entry.id === editingId); if (item?.resourceId != null) updateItem.mutate({ id: item.resourceId, title: editTitle.trim(), summary: editSummary.trim(), tags: editTags.trim(), body: item.kind === "note" ? editBody : item.body }); }}><Check size={14} /> 변경 저장</button></footer>
            </section>
          </div>
        )}

        {editorOpen && (
          <div className="archive-editor-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !isSaving) closeEditor(); }}>
            <section className="archive-editor-window" role="dialog" aria-modal="true" aria-labelledby="archive-editor-title">
              <header className="archive-editor-head"><div><span className="archive-panel-index">NEW / MEMORY CARD</span><h2 id="archive-editor-title">무엇을 남길까요?</h2></div><button className="archive-icon-button" onClick={closeEditor} aria-label="닫기" disabled={isSaving}><X size={17} /></button></header>
              <div className="archive-kind-chooser" role="tablist" aria-label="자료 유형">
                {(["video", "image", "file", "note"] as const).map((option) => {
                  const label = option === "video" ? "영상 링크" : option === "image" ? "사진" : option === "file" ? "PDF·TXT" : "메모";
                  const icon = option === "video" ? <Film size={14} /> : option === "image" ? <ImageIcon size={14} /> : option === "file" ? <FileArchive size={14} /> : <StickyNote size={14} />;
                  return <button type="button" key={option} role="tab" aria-selected={kind === option} className={kind === option ? "active" : ""} onClick={() => { setKind(option); setFile(null); setCover(null); setSourceUrl(""); }}>{icon}{label}</button>;
                })}
              </div>
              <form className="archive-editor-fields" onSubmit={handleSave}>
                {kind === "video" && <label>영상 주소<input type="url" value={sourceUrl} onChange={(event) => setSourceUrl(event.target.value)} placeholder="YouTube 또는 Instagram Reel 링크" maxLength={2048} required /><small>Shorts·일반 YouTube 영상과 공개 Instagram Reels를 지원합니다.</small></label>}
                <label>제목<input value={title} onChange={(event) => setTitle(event.target.value)} placeholder={kind === "video" ? "이 장면을 기억할 이름" : kind === "note" ? "메모 제목" : "자료 이름"} maxLength={200} required /></label>
                {kind !== "note" && <label>한 줄 요약<input value={summary} onChange={(event) => setSummary(event.target.value)} placeholder="무슨 내용인지 짧게 적어 두세요" maxLength={1000} /></label>}
                {kind === "note" && <><label>요약<input value={summary} onChange={(event) => setSummary(event.target.value)} placeholder="목록에서 한눈에 볼 짧은 설명 (선택)" maxLength={1000} /></label><label>메모<textarea value={body} onChange={(event) => setBody(event.target.value)} placeholder="생각, 문장, 아이디어를 자유롭게 적어 두세요…" maxLength={50_000} rows={6} /></label></>}
                {kind === "video" && <label>표지 이미지 <span className="optional-label">선택 — Instagram 카드용</span><input type="file" accept="image/jpeg,image/png,image/webp,image/gif" onChange={handleCoverChange} /><small>{cover ? `${cover.name} · ${formatBytes(cover.size)}` : "YouTube 썸네일은 자동으로 가져옵니다. Instagram은 직접 표지를 넣을 수 있어요. 8MB 이하."}</small></label>}
                {(kind === "image" || kind === "file") && <label className="archive-file-picker"><span>{kind === "image" ? <ImageIcon size={17} /> : <Upload size={17} />}{kind === "image" ? "사진 선택" : "문서 선택"}</span><input type="file" accept={kind === "image" ? "image/jpeg,image/png,image/webp,image/gif" : "application/pdf,text/plain,.pdf,.txt"} onChange={handleFileChange} />{file && <small>{file.name} · {formatBytes(file.size)}</small>}<small>{kind === "image" ? "JPG · PNG · WebP · GIF, 최대 8MB" : "PDF · TXT, 최대 8MB"}</small></label>}
                <label>태그 <span className="optional-label">쉼표로 구분</span><input value={tags} onChange={(event) => setTags(event.target.value)} placeholder="음악, 레퍼런스, 아이디어" maxLength={500} /></label>
                <div className="archive-editor-disclosure"><ShieldCheck size={13} /><span>자료는 이 비공개 아카이브에만 저장됩니다. 영상은 재생 버튼을 누를 때 YouTube 또는 Instagram에서 불러오며, 공개·임베드 가능한 링크만 재생됩니다.</span></div>
                <footer className="archive-editor-footer"><span>{kind === "note" ? "메모 최대 50,000자" : "큰 동영상 파일 대신 링크를 저장합니다."}</span><button type="submit" className="archive-add-button" disabled={isSaving}>{isSaving ? <Loader2 className="archive-spinner" size={14} /> : <Plus size={14} />}{isSaving ? "보관 중…" : "기억 저장"}</button></footer>
              </form>
            </section>
          </div>
        )}

        <div className="archive-bottom-note"><LockKeyhole size={13} /><span>공유된 코드와 이 브라우저의 열린 세션을 비밀로 보관하세요. YouTube·Instagram 임베드는 사용자가 재생할 때만 외부에서 불러옵니다.</span></div>
      </section>
      <footer className="archive-footer"><span>MEMORY ROOM / PRIVATE BY DESIGN</span><Link href="/">PORTFOLIO HOME ↗</Link></footer>
    </main>
  );
}
